from django.urls import path
from . import views  # Испортируем views для указания пути.

urlpatterns = [
    path('', views.home, name='home'),  # Через ссылку показываем какой запрос нужно обрабатывать.
]